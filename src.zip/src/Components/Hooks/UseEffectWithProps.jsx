import React from 'react'

const UseEffectWithProps = ({data}) => {
  return (
    <div>
      <h4>User Effect Child Count {data}</h4>
    </div>
  )
}

export default UseEffectWithProps