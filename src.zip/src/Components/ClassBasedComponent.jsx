import React, { Component } from "react";

class ClassBasedComponent extends Component{
    render(){
        return(
            <h1>Hello i am a class Component</h1>
        )
    }
}

export default ClassBasedComponent